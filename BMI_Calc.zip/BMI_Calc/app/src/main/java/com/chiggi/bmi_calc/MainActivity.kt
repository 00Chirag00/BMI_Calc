package com.chiggi.bmi_calc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val weightText = findViewById<EditText>(R.id.etWeight)
        val heightText = findViewById<EditText>(R.id.etHeight)
        val indexText = findViewById<TextView>(R.id.tvIndex)
        val calcBtn = findViewById<Button>(R.id.btnCalc)
        val statementText = findViewById<TextView>(R.id.tvStat)
        val infoText = findViewById<TextView>(R.id.tvInfo)
        calcBtn.setOnClickListener {
            val weight = weightText.text.toString().toFloat()
            val height = heightText.text.toString().toFloat()
            val bmi = weight/((height/100)*(height/100))

            indexText.setText("$bmi")

            if( bmi >= 18.5 && bmi<= 24.9){
                statementText.setText("You are Healthy!!")
        }
            else{

                if(bmi>24.9){
                    statementText.setText("Overweight!!")
                }
                else{
                    statementText.setText("Underweight!!")
                }
            }
            infoText.setText("(Normal BMI range is 18.5 to 24.9)")
        }
//            else{
//                Toast.makeText("@","Kindly fill your height and weight properly!!",
//                Toast.LENGTH_SHORT)
//
//            }

    }
}